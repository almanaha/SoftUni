package EXAMS.Feb2019Sample.SoftUniParking;

import java.util.*;

public class Parking {
    private Map<String, Car> cars;
    private int capacity;

    Parking(int capacity) {
        this.cars = new HashMap<>();
        this.capacity = capacity;
    }

    String addCar(Car car){
        if (this.cars.containsKey(car.getRegistrationNumber())){
            return "Car with that registration number, already exists!";
        }else if (this.cars.size() == this.capacity){
            return "Parking is full!";
        }

        this.cars.putIfAbsent(car.getRegistrationNumber(), car);
        return "Successfully added new car " + car.getMake() + " " +car.getRegistrationNumber();
    }


    String removeCar(String registrationNumber){
        if (!this.cars.containsKey(registrationNumber)){
            return "Car with that registration number, doesn't exists!";
        }
        this.cars.remove(registrationNumber);
        return "Successfully removed " + registrationNumber;
    }

    Car getCar(String registrationNumber){

        return this.cars.get(registrationNumber);
    }

    void removeSetOfRegistrationNumber(List<String> registrationNumber){

        for (String s : registrationNumber) {
            this.removeCar(s);
        }
    }

    public int getCount(){
        return this.cars.size();
    }
}
