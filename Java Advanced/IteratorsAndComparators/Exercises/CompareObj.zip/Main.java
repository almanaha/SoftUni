package IteratorsAndComparators.Exercises.ComparingObjects;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));

        List<Person> people = new ArrayList<>();

        String cmd;
        while (!"END".equals(cmd = sc.readLine())) {
            String[] data = cmd.split("\\s+");
            Person person = new Person(data[0], Integer.parseInt(data[1]), data[2]);
            people.add(person);
        }

        int n = Integer.parseInt(sc.readLine());
        Person compareP = people.get(n - 1);

        long equalPeopleCount = people.stream().filter(p -> p.compareTo(compareP) == 0).count();
        if (equalPeopleCount == 1){
            System.out.println("No matches");
        }else{
            System.out.printf("%d %d %d\n",
                    equalPeopleCount,people.size() - equalPeopleCount,people.size());
        }
    }
}
