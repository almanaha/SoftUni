package IteratorsAndComparators.Exercises.ComparingObjects;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Set;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));

        Set<Person> peopleByName = new TreeSet<>(new PeopleByNames());
        Set<Person> peopleByAge = new TreeSet<>(new PeopleByAge());
        int n = Integer.parseInt(sc.readLine());

        while (n-- > 0) {
            String[] data = sc.readLine().split("\\s+");
            Person person = new Person(data[0], Integer.parseInt(data[1]));
            peopleByName.add(person);
            peopleByAge.add(person);
        }

        for (Person person : peopleByName) {
            System.out.println(person);
        }
        for (Person person : peopleByAge) {
            System.out.println(person);
        }

    }
}
