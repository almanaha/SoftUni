package IteratorsAndComparators.Exercises.ComparingObjects;

import java.util.Comparator;

public class PeopleByNames implements Comparator<Person> {

    @Override
    public int compare(Person first, Person second) {
        return first.getName().length() - second.getName().length() == 0 ?
                first.getName().toLowerCase().charAt(0) - second.getName().toLowerCase().charAt(0) :
                first.getName().length() - second.getName().length();
    }
}
