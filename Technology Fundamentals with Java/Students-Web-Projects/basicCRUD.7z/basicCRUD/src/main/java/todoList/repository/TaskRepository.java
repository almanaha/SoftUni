package todoList.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import todoList.entity.Task;

//Repository is our local access to the DB
public interface TaskRepository extends JpaRepository<Task, Integer> {

}
