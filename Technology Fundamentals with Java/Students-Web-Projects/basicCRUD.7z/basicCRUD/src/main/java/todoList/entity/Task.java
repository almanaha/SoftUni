package todoList.entity;



import javax.persistence.*;

@Entity
@Table(name = "tasks")  //Naming table
public class Task {

    private Integer id;
    private String title;
    private String comments;

    public Task(String title, String comments) {
        this.title = title;
        this.comments = comments;
    }

    public Task(){

    }

    @Id //it will be a PrimaryKey
    @GeneratedValue(strategy = GenerationType.IDENTITY) //DB will generate the values automatically
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Column(nullable = false)   //This field cannot be empty
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Column(columnDefinition = "text", nullable = false) //Give the length of field no limits
    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
}
