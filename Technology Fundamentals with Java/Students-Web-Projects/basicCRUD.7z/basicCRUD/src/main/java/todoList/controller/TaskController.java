package todoList.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.servlet.ModelAndView;
import todoList.bindingModel.TaskBindingModel;
import todoList.entity.Task;
import todoList.repository.TaskRepository;

import java.util.List;

@Controller //Gives us access to requests and ability to respond
public class TaskController {

    private final TaskRepository taskRepository;

    @Autowired  //Initializes and configures our repositories automatically
    public TaskController(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    //FOR LISTING DATA:

    @GetMapping("/")    //to preview data, not to submit
    public ModelAndView index(ModelAndView modelAndView) {

        List<Task> tasks = this.taskRepository.findAll();
        modelAndView.setViewName("base-layout");    //Sets the view name
        modelAndView.addObject("view", "task/index"); //Inserts the view for the index page
        modelAndView.addObject("tasks", tasks); //Add tasks from the DB to the modelAndView

        return modelAndView;    //return it as a result
    }

    //FOR CREATING NEW TASKs:

    @GetMapping("/create")
    public ModelAndView create(ModelAndView modelAndView) {

        modelAndView.setViewName("base-layout");
        modelAndView.addObject("view", "task/create");
        return modelAndView;

    }

    @PostMapping("/create")
    public String create(Task task) {

        this.taskRepository.saveAndFlush(task); //Enforcing the sync of model state with the DB
        return ("redirect:/");
    }


    //FOR EDIT:

    @GetMapping("/edit/{id}")
    public ModelAndView edit(@PathVariable(value = "id") Integer id, ModelAndView modelAndView) {

        Task task = this.taskRepository.findById(id).get(); //To get the task from the DB using our repository

        modelAndView.setViewName("base-layout");
        modelAndView.addObject("view", "task/edit");
        modelAndView.addObject("task", task);

        return modelAndView;
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable(value = "id") Integer id, TaskBindingModel taskBindingModel) {

        Task taskToEdit = this.taskRepository.findById(id).get();
        taskToEdit.setTitle(taskBindingModel.getTitle());
        taskToEdit.setComments(taskBindingModel.getComments());

        this.taskRepository.saveAndFlush(taskToEdit);

        return "redirect:/";
    }


    //FOR DELETE:

    @GetMapping("/delete/{id}")
    public ModelAndView delete(@PathVariable(value = "id") Integer id, ModelAndView modelAndView){

        Task task = this.taskRepository.findById(id).get(); //To get the task from the DB using our repository

        modelAndView.setViewName("base-layout");
        modelAndView.addObject("view", "task/delete");
        modelAndView.addObject("task", task);

        return modelAndView;
    }

    @PostMapping("/delete/{id}")
    public String edit(@PathVariable(value = "id") Integer id) {

        this.taskRepository.deleteById(id); //Remove from repo and DB

        return "redirect:/";
    }

}
