package rescueRegister.controllers;

import rescueRegister.bindingModels.MountaineerBindingModel;
import rescueRegister.entities.Mountaineer;
import rescueRegister.repositories.MountaineerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class MountaineerController {
    private final MountaineerRepository mountaineerRepository;

    @Autowired
    public MountaineerController(MountaineerRepository mountaineerRepository) {
        this.mountaineerRepository = mountaineerRepository;
    }


    @GetMapping("/")
    public ModelAndView index(ModelAndView modelAndView) {
        List<Mountaineer> people = this.mountaineerRepository.findAll();
        modelAndView.setViewName("base-layout");
        modelAndView.addObject("view", "mountaineer/index");
        modelAndView.addObject("mountaineers", people);
        return modelAndView;
    }

    @GetMapping("/create")
    public ModelAndView create(ModelAndView modelAndView) {
        modelAndView.setViewName("base-layout");
        modelAndView.addObject("view", "mountaineer/create");
        return modelAndView;
    }

    @PostMapping("/create")
    public String create(MountaineerBindingModel mountaineerBindingModel) {
        Mountaineer m = new Mountaineer();
        m.setAge(mountaineerBindingModel.getAge());
        m.setGender(mountaineerBindingModel.getGender());
        m.setLastSeenDate(mountaineerBindingModel.getLastSeenDate());
        m.setName(mountaineerBindingModel.getName());

        this.mountaineerRepository.saveAndFlush(m);
        return "redirect:/";
    }

    @GetMapping("/edit/{id}")
    public ModelAndView edit(@PathVariable(value = "id") Integer id, ModelAndView modelAndView) {
        Mountaineer m = this.mountaineerRepository.findById(id).get();
        modelAndView.setViewName("base-layout");
        modelAndView.addObject("view","mountaineer/edit");
        modelAndView.addObject("mountaineer",m);
        return modelAndView;

    }

    @PostMapping("edit/{id}")
    public String edit(@PathVariable(value = "id") Integer id, MountaineerBindingModel mountaineerBindingModel) {
        Mountaineer mToEdit = this.mountaineerRepository.findById(id).get();
        mToEdit.setName(mountaineerBindingModel.getName());
        mToEdit.setLastSeenDate(mountaineerBindingModel.getLastSeenDate());
        mToEdit.setGender(mountaineerBindingModel.getGender());
        mToEdit.setAge(mountaineerBindingModel.getAge());

        this.mountaineerRepository.saveAndFlush(mToEdit);
        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public ModelAndView remove(@PathVariable(value = "id") Integer id, ModelAndView modelAndView) {
        Mountaineer mToDelete = this.mountaineerRepository.findById(id).get();
        modelAndView.setViewName("base-layout");
        modelAndView.addObject("view","mountaineer/remove");
        modelAndView.addObject("mountaineer",mToDelete);
        return modelAndView;
    }

    @PostMapping("/delete/{id}")
    public String remove(Mountaineer mountaineer) {
        this.mountaineerRepository.delete(mountaineer);
        return "redirect:/";
    }
}
