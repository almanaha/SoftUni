package com.softuni.entity;

public class Calculator {
    private Double leftOperand;
    private String operator;
    private Double rightOperand;

    public Calculator() {
    }
    public Calculator(Double leftOperand, String operator, Double rightOperand) {
        this.leftOperand = leftOperand;
        this.operator = operator;
        this.rightOperand = rightOperand;
    }
    public double getLeftOperand() {
        return leftOperand;
    }
    public double getRightOperand() {
        return rightOperand;
    }
    public String getOperator() {
        return operator;
    }
    public double calculateResult() {
        switch (this.operator) {
            case "+":
                return this.getLeftOperand() + this.getRightOperand();
            case "-":
                return this.getLeftOperand() - this.getRightOperand();
            case "*":
                return this.getLeftOperand() * this.getRightOperand();
            case "/":
                return this.getLeftOperand() / this.getRightOperand();
            default:
                return 0d;
        }
    }
}
